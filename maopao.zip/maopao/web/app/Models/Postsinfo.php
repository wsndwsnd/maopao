<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Postsinfo extends Model
{
    //
    public $table = 'posts_info';
    public $primaryKey = 'id';

    
}
