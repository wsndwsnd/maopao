<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Slide extends Model
{
    public $table = 'slides';
    public $primaryKey = 'slide_id';
}
