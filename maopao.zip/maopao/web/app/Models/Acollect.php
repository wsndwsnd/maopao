<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Acollect extends Model
{
    public $table = 'a_collect';
}
