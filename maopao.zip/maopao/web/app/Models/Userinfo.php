<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Userinfo extends Model
{
    //
    public $table = 'user_details';
    public $primaryKey = 'id';

}
