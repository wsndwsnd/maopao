<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Daodu extends Model
{
    //
    public $table = 'categories';
}
